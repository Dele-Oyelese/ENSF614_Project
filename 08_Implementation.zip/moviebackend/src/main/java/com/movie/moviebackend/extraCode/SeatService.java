package com.movie.moviebackend.extraCode;

public class SeatService {
}
