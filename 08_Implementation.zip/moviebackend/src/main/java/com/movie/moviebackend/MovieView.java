package com.movie.moviebackend;

public class MovieView {

    public interface  id {}

    public interface CoreData extends id {}

    public interface FullData extends CoreData {}

}
