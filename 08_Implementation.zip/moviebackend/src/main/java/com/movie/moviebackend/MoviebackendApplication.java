package com.movie.moviebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviebackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoviebackendApplication.class, args);
	}

}
