import '../../App.css';
import React from 'react';

import Seating from '../Seating'

function Home(){
    return(
        <>       

        
        {/* <Seating/> */}
        </>
    );
}

export default Home;